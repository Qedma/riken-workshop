# pylint: disable=missing-function-docstring,missing-class-docstring,missing-module-docstring
import qedma_api


class JobAlreadyRunningException(Exception):
    def __init__(self, job_details: qedma_api.JobDetails, action_required_message: str) -> None:
        message = (
            f"Another job was already created (status={job_details.status}, "
            f"job_id='{job_details.job_id}', created_at={job_details.created_at}). "
            f"To continue running the job please run {action_required_message}. "
            f"To cancel the job run qedma_client.cancel_job(job_id='{job_details.job_id}')"
        )
        super().__init__(message)
