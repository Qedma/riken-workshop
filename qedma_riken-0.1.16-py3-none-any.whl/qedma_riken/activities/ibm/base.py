# pylint: disable=missing-function-docstring,missing-class-docstring,missing-module-docstring


class BaseActivity:  # pylint: disable=too-few-public-methods
    def __init__(self, token: str):
        self._token = token
