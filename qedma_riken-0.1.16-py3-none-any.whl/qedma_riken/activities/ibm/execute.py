# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring
import base64
import dataclasses
import datetime
import enum
import hashlib
import io
import time
from typing import Literal

import loguru
import numpy as np
import qiskit
import qiskit.circuit
import qiskit.primitives
import qiskit.providers
import qiskit.qpy
import qiskit_ibm_runtime
import temporalio.activity
import temporalio.exceptions

from .backend import Service
from .base import BaseActivity
from .session import Session


logger = loguru.logger
QUERY_JOB_STATUS_INTERVAL = 5.0
QUERY_JOB_STATUS_ACTIVITY_MAX_DELAY = 120.0


class Errors(str, enum.Enum):  # pylint: disable=too-few-public-methods
    SESSION_CLOSED = "SESSION_CLOSED"
    CIRCUIT_JOB_EXECUTION_FAILED = "CIRCUIT_JOB_EXECUTION_FAILED"
    JOB_NOT_DONE = "JOB_NOT_DONE"

    def __str__(self) -> str:
        return self.value


@dataclasses.dataclass
class IBMJobMetrics:
    created_timestamp: datetime.datetime | None
    start_timestamp: datetime.datetime | None
    finish_timestamp: datetime.datetime | None
    qpu_usage_sec: int
    est_start_time: datetime.datetime | None
    est_end_time: datetime.datetime | None


@dataclasses.dataclass
class BackendParams:
    name: str
    service: Service


@dataclasses.dataclass
class IbmSendCircuitsRequest:
    binary_circuits: str
    n_shots: int
    backend: BackendParams
    session_id: str
    processor_type: Literal["heron", "eagle"]
    private: bool


@dataclasses.dataclass
class IbmGetResultsRequest:
    job_id: str
    active_qubits: set[int]
    service: Service


@dataclasses.dataclass
class IbmGetResultsResult:
    job_result: str
    qpu_usage_time_sec: int


@dataclasses.dataclass
class IbmWaitForNonInitialStateRequest:
    job_id: str
    service: Service


class ExecuteActivities(BaseActivity):
    @temporalio.activity.defn(name="ibm_wait_for_non_initial_state")
    def ibm_wait_for_non_initial_state(self, req: IbmWaitForNonInitialStateRequest) -> bool:
        """
        Poll job status until it is no longer queued or initializing.
        Return True if job is running, False otherwise.
        """
        try:
            job = req.service.get_service(self._token).job(req.job_id)
            start_time = time.monotonic()

            while time.monotonic() - start_time < QUERY_JOB_STATUS_ACTIVITY_MAX_DELAY:
                temporalio.activity.heartbeat(f"Polling status for job {req.job_id}")

                status = job.status()
                logger.info(
                    "Polled job status",
                    job_id=req.job_id,
                    status=status,
                )

                # If job is no longer queued or initializing, we're done
                # The following is the (type-safer) equivalent of:
                # status not in (JobStatus.INITIALIZING, JobStatus.QUEUED)
                is_running = job.running()
                if is_running or job.in_final_state():
                    logger.info(
                        "Job is no longer initializing or queued",
                        job_id=req.job_id,
                        status=status,
                    )
                    return is_running  # type: ignore[no-any-return]

                time.sleep(QUERY_JOB_STATUS_INTERVAL)

            return False
        except qiskit_ibm_runtime.exceptions.IBMError as e:
            logger.error("IBM error getting results", job_id=req.job_id, error=str(e))
            raise temporalio.exceptions.ApplicationError(
                f"IBM error getting results for {req.job_id}: {e}",
                non_retryable=False,
            ) from e

        except Exception as e:
            logger.error("Error polling job status", job_id=req.job_id, error=str(e))
            raise temporalio.exceptions.ApplicationError(
                f"Error polling job status for {req.job_id}: {e}",
                non_retryable=not temporalio.activity.is_worker_shutdown(),
            ) from e

    @temporalio.activity.defn(name="ibm_get_results")
    def ibm_get_results(  # pylint: disable=too-many-statements,too-many-branches, too-many-locals
        self,
        req: IbmGetResultsRequest,
    ) -> IbmGetResultsResult:
        try:
            job = req.service.get_service(self._token).job(req.job_id)

            temporalio.activity.heartbeat(f"Waiting for job {req.job_id} to finish")
            is_job_done = job.in_final_state()
            start_time = time.time()

            # Wait for final status, even though qiskit do it themselves, as they use time.sleep
            # (at least up to version 0.26.0)
            while (
                not is_job_done and time.time() - start_time < QUERY_JOB_STATUS_ACTIVITY_MAX_DELAY
            ):
                time.sleep(QUERY_JOB_STATUS_INTERVAL)
                temporalio.activity.heartbeat(f"Waiting for job {req.job_id} to finish")
                is_job_done = job.in_final_state()

            if not is_job_done:
                raise temporalio.exceptions.ApplicationError(
                    f"Job {req.job_id} is not yet done, status is {job.status()}",
                    non_retryable=False,
                    type=Errors.JOB_NOT_DONE,
                )

            logger.info("Job done", job_id=req.job_id, status=job.status())

            # We shouldn't raise for every failure. If only one job fails we need to rerun it
            # (and only it), if it keeps failing we can still salvage the experiment, we can
            # to work with incomplete data just fine.
            # TODO: Handle rerunning specific jobs  # pylint: disable=fixme
            if not job.done():  # done in qiskit terminology is success
                try:
                    job_log = job.logs()
                except qiskit_ibm_runtime.exceptions.IBMRuntimeError:
                    job_log = None

                if job.errored():
                    job_error = job.error_message()
                else:
                    job_error = None

                logger.error(
                    "Job did not succeed.",
                    job_id=req.job_id,
                    job_log=job_log,
                    job_error=job_error,
                )

                raise temporalio.exceptions.ApplicationError(
                    f"Job {req.job_id} has status {job.status()}, error={job_error}",
                    non_retryable=True,
                    type=Errors.CIRCUIT_JOB_EXECUTION_FAILED,
                )

            temporalio.activity.heartbeat("Downloading results")
            logger.info("Downloading results", job_id=req.job_id)
            raw_result = job._api_client.job_results(  # pylint: disable=protected-access
                job_id=job.job_id()
            )

            temporalio.activity.heartbeat("Downloading metrics")
            logger.info("Downloading metrics", job_id=req.job_id)
            ibm_metrics = job.metrics()
            temporalio.activity.heartbeat("Downloaded metrics")
            logger.info("Downloaded metrics", job_id=req.job_id)

            metrics = IBMJobMetrics(
                created_timestamp=self._parse_ibm_timestamp(
                    ibm_metrics["timestamps"].get("created")
                ),
                start_timestamp=self._parse_ibm_timestamp(ibm_metrics["timestamps"].get("running")),
                finish_timestamp=self._parse_ibm_timestamp(
                    ibm_metrics["timestamps"].get("finished")
                ),
                qpu_usage_sec=ibm_metrics["usage"]["quantum_seconds"],
                est_start_time=self._parse_ibm_timestamp(ibm_metrics.get("estimated_start_time")),
                est_end_time=self._parse_ibm_timestamp(
                    ibm_metrics.get("estimated_completion_time")
                ),
            )

            logger.info(
                "Job completed successfully",
                job_id=req.job_id,
                created_at=metrics.created_timestamp,
                started_at=metrics.start_timestamp,
                finished_at=metrics.finish_timestamp,
                qpu_usage_sec=metrics.qpu_usage_sec,
                est_start_time=metrics.est_start_time,
                est_end_time=metrics.est_end_time,
            )

            return IbmGetResultsResult(raw_result, metrics.qpu_usage_sec)
        except temporalio.exceptions.TemporalError:
            raise
        except qiskit_ibm_runtime.exceptions.IBMError as e:
            logger.error("IBM error getting results", job_id=req.job_id, error=str(e))
            raise temporalio.exceptions.ApplicationError(
                f"IBM error getting results for {req.job_id}: {e}",
                non_retryable=False,
            ) from e
        except Exception as e:
            logger.error("Unexpected error getting results", job_id=req.job_id, error=str(e))
            raise temporalio.exceptions.ApplicationError(
                f"Unexpected error getting results: {e}",
                non_retryable=not temporalio.activity.is_worker_shutdown(),
            ) from e

    @temporalio.activity.defn(name="ibm_send_circuits")
    def ibm_send_circuits(self, req: IbmSendCircuitsRequest) -> str:
        logger.info(f"sending circuits to IBM cloud... session: {req.session_id}")
        runtime_service = req.backend.service.get_service(self._token)
        if req.processor_type == "heron":
            backend = runtime_service.backend(req.backend.name, use_fractional_gates=True)
        else:
            backend = runtime_service.backend(req.backend.name)

        if not isinstance(backend, qiskit_ibm_runtime.IBMBackend):
            raise ValueError(f"Backend {req.backend.name} is not an IBM backend")

        circuits = qiskit.qpy.load(io.BytesIO(base64.b64decode(req.binary_circuits.encode())))
        max_execution_time = self._calculate_max_execution_time(circuits, req.n_shots)
        with Session(
            backend=backend,
            session_id=req.session_id,
        ) as session:
            details = session.details()
            if details and (
                details["state"] in ("closed", "cancelled", "inactive")
                or not details["accepting_jobs"]
            ):
                raise temporalio.exceptions.ApplicationError(
                    f"Session {req.session_id} is closed or not accepting jobs",
                    details,
                    non_retryable=True,
                    type=Errors.SESSION_CLOSED,
                )

            sampler = qiskit_ibm_runtime.SamplerV2(mode=session)
            sampler.options.max_execution_time = max_execution_time
            sampler.options.environment.job_tags = self._create_job_tags()

            if req.private:
                sampler.options.environment.private = True

            job = sampler.run(pubs=circuits, shots=req.n_shots)

        return job.job_id()  # type: ignore[no-any-return]

    def _create_job_tags(self) -> list[str]:
        workflow_id = temporalio.activity.info().workflow_id

        root_wf_id, _, sub_wf_id = workflow_id.partition("/")

        tags = ["QESEM", f"QEDMA-{root_wf_id}"]

        if sub_wf_id:
            encrypted_sub_wf_id = hashlib.md5(sub_wf_id.encode()).hexdigest()
            tags.append(f"QEDMA-{encrypted_sub_wf_id}")

        return tags

    def _calculate_max_execution_time(  # type: ignore[no-any-unimported]
        self,
        circuits: list[qiskit.QuantumCircuit],
        num_shots: int,
        slowness_factor: float | None = None,
    ) -> int:
        """
        Calculate the maximum execution time for the given circuits and number of shots.
        """
        circuits_number = len(circuits)
        circs_per_sec = 1
        circs_time = circuits_number / circs_per_sec

        shots_per_sec = 1000
        total_num_shots = num_shots * circuits_number
        shot_time = (total_num_shots / shots_per_sec) * (slowness_factor or 1)

        return max(300, int(np.ceil(circs_time + shot_time)))

    def _parse_ibm_timestamp(self, timestamp: str | None) -> datetime.datetime | None:
        """
        Python 3.10 does not understand IBM's timestamps (ISO 8601 with Z instead of +00:00).
        """
        if timestamp is None:
            return None

        timestamp = timestamp.replace("Z", "+00:00")
        if "." not in timestamp:
            timestamp = timestamp.replace("+", ".000000+")
        microseconds = timestamp[timestamp.index(".") + 1 : timestamp.index("+")]
        timestamp = timestamp.replace("." + microseconds, "." + microseconds.ljust(6, "0"))

        return datetime.datetime.fromisoformat(timestamp).astimezone(tz=datetime.timezone.utc)
