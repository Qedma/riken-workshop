# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring
import dataclasses
import json
from typing import Literal

import qiskit_ibm_runtime
import temporalio.activity

from .base import BaseActivity


@dataclasses.dataclass(unsafe_hash=True)
class Service:
    instance: str
    channel: Literal["ibm_cloud", "ibm_quantum_platform"]

    def get_service(self, token: str) -> qiskit_ibm_runtime.QiskitRuntimeService:  # type: ignore[no-any-unimported] # pylint: disable=line-too-long
        return qiskit_ibm_runtime.QiskitRuntimeService(
            instance=self.instance,
            token=token,
            channel=self.channel,
        )


@dataclasses.dataclass(unsafe_hash=True)
class GetBackendConfigurationParams:
    backend_name: str
    service: Service
    processor_type: Literal["heron", "eagle"] = "heron"


@dataclasses.dataclass
class GetBackendResult:
    serialized_configuration: str
    serialized_properties: str


class BackendActivities(BaseActivity):  # pylint: disable=too-few-public-methods
    def __init__(self, token: str):
        super().__init__(token)
        self._cached_results: dict[GetBackendConfigurationParams, GetBackendResult] = {}

    @temporalio.activity.defn(name="get_backend")
    def get_backend(self, params: GetBackendConfigurationParams) -> GetBackendResult:
        if params not in self._cached_results:

            service = params.service.get_service(self._token)
            if params.processor_type == "heron":
                backend = service.backend(params.backend_name, use_fractional_gates=True)
            else:
                backend = service.backend(params.backend_name)

            if not isinstance(backend, qiskit_ibm_runtime.IBMBackend):
                raise ValueError(f"Unsupported backend type: {type(backend)}")

            serialized_configuration = json.dumps(
                backend.configuration().to_dict(),
                cls=qiskit_ibm_runtime.utils.RuntimeEncoder,
            )
            serialized_properties = json.dumps(
                backend.properties().to_dict(),
                cls=qiskit_ibm_runtime.utils.RuntimeEncoder,
            )
            self._cached_results[params] = GetBackendResult(
                serialized_configuration=serialized_configuration,
                serialized_properties=serialized_properties,
            )
        return self._cached_results[params]
