# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring
import dataclasses

import loguru
import qiskit_ibm_runtime
import temporalio.activity

from .backend import Service
from .base import BaseActivity


logger = loguru.logger


@dataclasses.dataclass
class IbmJobsParams:
    job_ids: list[str]
    service: Service


class JobActivities(BaseActivity):  # pylint: disable=too-few-public-methods
    @temporalio.activity.defn(name="ibm_cancel_job")
    def ibm_cancel_jobs(
        self,
        params: IbmJobsParams,
    ) -> None:
        runtime_service = params.service.get_service(self._token)

        for job_id in params.job_ids:
            try:
                ibm_job = runtime_service.job(job_id)
                ibm_job.cancel()
            except qiskit_ibm_runtime.RuntimeJobNotFound:
                logger.warning("Job not found", job_id=job_id)
            except qiskit_ibm_runtime.RuntimeInvalidStateError as e:
                logger.warning("Job cannot be cancelled", job_id=job_id, error=e)
