# pylint: disable=missing-module-docstring, missing-class-docstring, missing-function-docstring
import dataclasses
import types
from typing import Literal, TypeAlias

import loguru
import qiskit.providers
import qiskit_ibm_runtime
import temporalio

from .backend import GetBackendConfigurationParams, Service
from .base import BaseActivity


logger = loguru.logger


@dataclasses.dataclass
class SessionParams:
    session_id: str
    backend_name: str
    service: Service


Status: TypeAlias = Literal[
    "INITIALIZING", "QUEUED", "RUNNING", "CANCELLED", "DONE", "ERROR", "UNKNOWN"
]


class Session(qiskit_ibm_runtime.Session):  # type: ignore[misc, no-any-unimported]  # pylint: disable=missing-class-docstring
    _initialized_session: str | None

    def __init__(  # type: ignore[no-any-unimported]
        self,
        backend: qiskit.providers.BackendV2,
        max_time: int | str | None = None,
        close_on_exit: bool = False,
        is_batch: bool = False,
        *,
        session_id: str | None,
    ):
        if session_id is not None:
            self._initialized_session = session_id
        else:
            self._initialized_session = None

        self._is_batch = is_batch
        super().__init__(backend=backend, max_time=max_time, create_new=session_id is None)

        self.close_on_exit = close_on_exit

        if not self._session_id:  # type: ignore[has-type]
            # Sessions are not generated for simulators, but if a session id was provided,
            # we should use it
            self._session_id = session_id

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: types.TracebackType | None,
    ) -> None:
        if self.close_on_exit:
            super().__exit__(exc_type, exc_val, exc_tb)

    def _create_session(self, *, create_new: bool | None = None) -> str:
        if not self._initialized_session:
            if self._is_batch:
                return qiskit_ibm_runtime.Batch._create_session(self)  # type: ignore[no-any-return] # pylint: disable=protected-access, line-too-long
            return super()._create_session(create_new=create_new)  # type: ignore[no-any-return]

        assert isinstance(self._initialized_session, str)
        return self._initialized_session


class SessionActivities(BaseActivity):
    @temporalio.activity.defn(name="qpu.ibm_cloud.start_session")
    def start_session(self, params: GetBackendConfigurationParams) -> str:
        session = Session(
            backend=params.service.get_service(self._token).backend(
                params.backend_name, use_fractional_gates=True
            ),
            is_batch=True,
            session_id=None,  # create new session
        )

        if session.session_id is None:
            raise RuntimeError("Failed to start session")

        return session.session_id  # type: ignore[no-any-return]

    @temporalio.activity.defn(name="qpu.ibm_cloud.close_batch")
    def close_batch(self, params: SessionParams) -> None:
        session = Session(
            backend=params.service.get_service(self._token).backend(
                params.backend_name, use_fractional_gates=True
            ),
            session_id=params.session_id,
        )
        try:
            session.close()
        except Exception:  # pylint: disable=broad-exception-caught
            logger.exception("Failed closing batch!")
