"""activities to interact with SQC"""

import dataclasses
import json
import random

import qiskit_ibm_runtime.fake_provider
import qiskit_ibm_runtime.fake_provider.fake_backend
import temporalio.activity


@dataclasses.dataclass
class QASMCircuitJob:
    """all parameters needed to send a circuit to the QPU via SQC"""

    qasm_circuit: str
    num_shots: int
    num_qubits: int
    backend: str


class SQC:
    """available SQC activities"""

    def __init__(self, token: str) -> None:
        self.token = token

    @temporalio.activity.defn(name="sqc.send_circuit")
    def send_circuit(self, qasm_circuit_job: QASMCircuitJob) -> dict[str, int]:
        """send circuit to qpu"""
        # sqc - TODO send to the real backend here
        fake_state1 = "".join(
            [str(random.randint(0, 1)) for x in range(qasm_circuit_job.num_qubits)]
        )
        fake_state2 = "".join(
            [str(random.randint(0, 1)) for x in range(qasm_circuit_job.num_qubits)]
        )
        fake_result = {fake_state1: 7, fake_state2: 8}
        return fake_result

    @temporalio.activity.defn(name="sqc.get_configuration")
    def get_configuration(self, backend_name: str) -> str:
        """get backend configuration"""
        # sqc - TODO get the real backend here
        backend = _get_fake_backend(backend_name)
        return json.dumps(
            backend.configuration().to_dict(), cls=qiskit_ibm_runtime.utils.RuntimeEncoder
        )

    @temporalio.activity.defn(name="sqc.get_properties")
    def get_properties(self, backend_name: str) -> str:
        """get backend properties"""
        # sqc - TODO get the real backend here
        backend = _get_fake_backend(backend_name)
        return json.dumps(
            backend.properties().to_dict(), cls=qiskit_ibm_runtime.utils.RuntimeEncoder
        )


def _get_fake_backend(  # type: ignore[no-any-unimported]
    backend_name: str,
) -> qiskit_ibm_runtime.fake_provider.fake_backend.FakeBackendV2:
    fake_provider = qiskit_ibm_runtime.fake_provider.FakeProviderForBackendV2()
    return fake_provider.backend(backend_name)
