"""Qedma Public API"""

import datetime
import hashlib
import sys
import uuid
from typing import Literal

import qedma_api.models
from qedma_api.clients import base_client

import qedma_riken.tools
import qedma_riken.worker as riken_worker
from qedma_riken import config
from qedma_riken.exceptions import JobAlreadyRunningException


class RikenProvider(qedma_api.models.RequestBase, qedma_api.models.BaseProvider):
    """Riken Provider params"""

    name: Literal["riken"] = "riken"
    user_id: str = str(uuid.uuid4())
    instance: str
    channel: Literal["ibm_quantum_platform", "ibm_cloud"] = "ibm_quantum_platform"


class RikenJobRequest(qedma_api.models.JobRequestBase):
    """Riken job request"""

    provider: RikenProvider


class RikenCharacterizationJobRequest(qedma_api.models.CharacterizationJobRequestBase):
    """Riken characterization job request"""

    provider: RikenProvider


class RikenClient(base_client.BaseClient):  # pylint: disable=missing-class-docstring
    def __init__(
        self,
        *,
        sqc_token: str,
        qedma_endpoint: str,
        api_token: str | None = None,
        provider: RikenProvider | None = None,
        timeout: int = 60,
    ) -> None:
        super().__init__(
            api_token=api_token,
            uri=qedma_endpoint,
            timeout=timeout,
            logger_scope="qedma-riken/client",
        )
        self._config = config.RikenConfig()
        self.provider = provider
        self._sqc_token = sqc_token
        self._api_token_hash = hashlib.sha256(self.api_token.encode()).hexdigest()
        self._worker = self._start_temporal_worker()

    def create_job(self, *args, **kwargs) -> qedma_api.models.ClientJobDetails:  # type: ignore[no-untyped-def]  # pylint: disable=line-too-long
        self._check_for_already_running_job()

        try:
            self.logger.info("creating job... (keep process running until job finishes)")
            job_details = super().create_job(*args, **kwargs)
            self._ensure_temporal_worker_is_up()
            return job_details
        except Exception:  # pylint: disable=broad-exception-caught
            self.logger.exception("received exception, stopping worker...")
            if self._worker:
                self._worker.stop()
                self._worker.join()
            raise

    def wait_for_time_estimation(
        self,
        job_id: str,
        *,
        interval: datetime.timedelta = qedma_api.clients.base_client.STATUS_POLLING_INTERVAL,
        max_poll_time: datetime.timedelta | None = None,
    ) -> datetime.timedelta | None:
        self._ensure_temporal_worker_is_up()
        return super().wait_for_time_estimation(
            job_id=job_id, interval=interval, max_poll_time=max_poll_time
        )

    def start_job(
        self,
        job_id: str,
        max_qpu_time: datetime.timedelta,
        options: qedma_api.models.JobOptions | None = None,
        force_start: bool = False,
    ) -> None:
        self._check_for_already_running_job()
        super().start_job(
            job_id=job_id, max_qpu_time=max_qpu_time, options=options, force_start=force_start
        )
        self._ensure_temporal_worker_is_up()

    def wait_for_job_complete(
        self,
        job_id: str,
        *,
        interval: datetime.timedelta = qedma_api.clients.base_client.STATUS_POLLING_INTERVAL,
        max_poll_time: datetime.timedelta | None = None,
        qedma_observable_model: bool = False,
    ) -> qedma_api.models.ClientJobDetails:

        self._ensure_temporal_worker_is_up()
        try:
            return super().wait_for_job_complete(
                job_id=job_id,
                interval=interval,
                max_poll_time=max_poll_time,
                qedma_observable_model=qedma_observable_model,
            )
        finally:
            if self._worker:
                self._worker.stop()

    def _ensure_temporal_worker_is_up(self) -> None:
        if self._worker is None or not self._worker.is_alive():
            self._worker = self._start_temporal_worker()

    def _start_temporal_worker(self) -> riken_worker.TemporalWorker:
        queue = f"{self._api_token_hash}-light"
        worker = riken_worker.TemporalWorker(
            queue=queue,
            sqc_token=self._sqc_token,
            temporal_address=self._config.riken_temporal_host,
            temporal_namespace=self._config.riken_temporal_namespace,
            temporal_api_key=self._config.riken_temporal_api_key,
            debug_mode=self._config.debug_mode,
        )

        worker.start()
        self.logger.info("Worker started")

        return worker

    def set_provider(self, provider: RikenProvider) -> None:
        """Set the provider of the client. (e.g. RikenProvider)"""
        self.provider = provider

    def _build_characterization_job_request(
        self, circuit: qedma_api.models.BareCircuit, backend: str, enable_notifications: bool
    ) -> RikenCharacterizationJobRequest:
        self.provider.user_id = self._api_token_hash
        return RikenCharacterizationJobRequest(
            circuit=circuit,
            provider=self.provider,
            backend=backend,
            enable_notifications=enable_notifications,
        )

    def _build_job_request(  # pylint: disable=too-many-positional-arguments
        self,
        circuit: qedma_api.models.ErrorSuppressionCircuit | qedma_api.models.Circuit,
        empirical_time_estimation: bool,
        backend: str,
        description: str,
        precision_mode: qedma_api.models.PrecisionMode | None,
        enable_notifications: bool,
        single_mitigation_step: bool = False,
    ) -> RikenJobRequest:
        self.provider.user_id = self._api_token_hash
        return RikenJobRequest(
            provider=self.provider,
            circuit=circuit,
            backend=backend,
            empirical_time_estimation=empirical_time_estimation,
            precision_mode=precision_mode,
            description=description,
            enable_notifications=enable_notifications,
            single_mitigation_step=single_mitigation_step,
        )

    def _config_loguru(self) -> None:
        self.logger.remove()  # Note that this affects anyone using loguru.logger
        self.logger.add(
            sys.stdout,
            format="{time:YYYY-MM-DD HH:mm:ss.SSS} | {level:<8} | {name} - {message}",
            filter=lambda record: record["extra"].get("scope") == self._logger_scope,
        )
        self.logger.add(
            qedma_riken.tools.logs_directory().joinpath("qedma_client_err.log"),
            rotation="50 MB",
            retention="14 days",
            format="{time:YYYY-MM-DD HH:mm:ss.SSS} | {level:<8} | {name} - {message}",
        )

    def _check_for_already_running_job(
        self,
    ) -> None:
        found_jobs = self.list_jobs(limit=1)
        if len(found_jobs) > 0:
            job_details = found_jobs[0]
            match job_details.status:
                case qedma_api.JobStatus.ESTIMATING:
                    raise JobAlreadyRunningException(
                        job_details=job_details,
                        action_required_message=f"qedma_client.wait_for_time_estimation(job_id='{job_details.job_id}') "  # pylint: disable=line-too-long
                        f"to get time estimation",
                    )
                case qedma_api.JobStatus.RUNNING:
                    raise JobAlreadyRunningException(
                        job_details=job_details,
                        action_required_message=f"qedma_client.wait_for_job_complete(job_id='{job_details.job_id}') "  # pylint: disable=line-too-long
                        f"to wait for job to finish",
                    )
