"""Client Config"""

import pydantic_settings


class RikenConfig(pydantic_settings.BaseSettings):
    """populated from Env"""

    riken_temporal_host: str = "localhost:7233"
    riken_temporal_api_key: str | None = None
    riken_temporal_namespace: str = "default"
    debug_mode: bool = False
