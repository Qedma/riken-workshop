# pylint hack - duplicate of compression codec in qedmaleet
"""compression codec for temporal client"""
import zlib
from collections.abc import Sequence

import temporalio.api.common.v1
import temporalio.converter


class CompressionCodec(temporalio.converter.PayloadCodec):
    """Compression codec"""

    def __init__(self, min_size: int = 4 * 1024) -> None:
        super().__init__()
        self.min_size = min_size

    async def encode(
        self, payloads: Sequence[temporalio.api.common.v1.Payload]
    ) -> list[temporalio.api.common.v1.Payload]:
        res = []
        for p in payloads:
            if p.ByteSize() >= self.min_size:
                res.append(
                    temporalio.api.common.v1.Payload(
                        metadata={"encoding": b"binary/zlib"},
                        data=zlib.compress(p.SerializeToString()),
                    )
                )
            else:
                res.append(p)
        return res

    async def decode(
        self, payloads: Sequence[temporalio.api.common.v1.Payload]
    ) -> list[temporalio.api.common.v1.Payload]:
        ret: list[temporalio.api.common.v1.Payload] = []
        for p in payloads:
            if p.metadata.get("encoding", b"") != b"binary/zlib":
                ret.append(p)
            else:
                ret.append(temporalio.api.common.v1.Payload.FromString(zlib.decompress(p.data)))
        return ret
