# pylint: disable=missing-function-docstring,missing-class-docstring,missing-module-docstring
import logging
import pathlib
from collections.abc import Sequence
from logging.handlers import RotatingFileHandler

from qedma_api import helpers


DEPENDENCIES_ERROR_LOGFILE = "dependencies_err.log"


def logs_directory() -> pathlib.Path:
    directory_path = pathlib.Path(
        pathlib.Path.home().joinpath(helpers.CONFIG_DIRECTORY).joinpath("logs")
    )
    directory_path.mkdir(exist_ok=True, parents=True)

    return directory_path


def redirect_dependencies_logs(package_names: Sequence[str]) -> None:
    logging.basicConfig(level=logging.INFO)
    root_logger = logging.getLogger()
    for handler in list(root_logger.handlers):
        root_logger.removeHandler(handler)
    root_logger.addHandler(logging.NullHandler())

    file_path = logs_directory().joinpath(DEPENDENCIES_ERROR_LOGFILE)
    file_handler = RotatingFileHandler(file_path, maxBytes=50 * 1024 * 1024, backupCount=10)
    file_handler.setFormatter(
        logging.Formatter(
            "[%(asctime)s] %(levelname)s [%(name)s.%(funcName)s:%(lineno)d] %(message)s",
            datefmt="%Y-%m-%dT%H:%M:%S",
        )
    )
    file_handler.setLevel(logging.INFO)

    for package in package_names:
        package_logger = logging.getLogger(package)
        for handler in list(package_logger.handlers):
            package_logger.removeHandler(handler)
        package_logger.addHandler(logging.NullHandler())
        package_logger.addHandler(file_handler)
