"""SQC temporal worker"""

import asyncio
import concurrent.futures
import dataclasses
import logging
import os
import threading
from typing import Callable, List

import loguru
import temporalio
import temporalio.client
import temporalio.converter
import temporalio.runtime
import temporalio.worker

import qedma_riken.compression_codec
import qedma_riken.tools
from qedma_riken.activities import (
    BackendActivities,
    ExecuteActivities,
    JobActivities,
    SessionActivities,
    sqc,
)


logger = loguru.logger


class TemporalWorker(threading.Thread):
    """Temporal worker"""

    def __init__(
        self,
        *,
        queue: str,
        sqc_token: str,
        temporal_address: str,
        temporal_namespace: str,
        temporal_api_key: str | None = None,
        debug_mode: bool = False,
    ):
        self._queue = queue
        self._sqc_token = sqc_token
        self._temporal_address = temporal_address
        self._temporal_namespace = temporal_namespace
        self._temporal_api_key = temporal_api_key
        self._debug_mode = debug_mode
        self._worker: temporalio.worker.Worker | None = None
        self._loop: asyncio.AbstractEventLoop | None = None

        if not self._debug_mode:
            qedma_riken.tools.redirect_dependencies_logs(["qiskit_ibm_runtime", "temporalio"])

        super().__init__()

    def run(self) -> None:
        self._loop = asyncio.new_event_loop()

        try:
            self._loop.run_until_complete(self.async_run())
        except Exception:
            self._loop.run_until_complete(self._loop.shutdown_asyncgens())
            self._loop.close()
            raise

    async def async_run(self) -> None:
        """run worker"""
        max_threads = 4 + (
            len(os.sched_getaffinity(0))
            if hasattr(os, "sched_getaffinity")
            else (os.cpu_count() or 1)
        )
        self._worker = temporalio.worker.Worker(
            client=await self._create_temporal_client(),
            task_queue=self._queue,
            activities=self._get_activities(),
            activity_executor=concurrent.futures.ThreadPoolExecutor(max_workers=max_threads),
            workflow_runner=temporalio.worker.UnsandboxedWorkflowRunner(),
            debug_mode=self._debug_mode,
        )
        logger.info("running worker with max {max_threads} threads", max_threads=max_threads)

        await self._worker.run()

    def stop(self) -> None:
        """stop worker"""
        logger.info("Worker shutting down")
        if self._worker and self._loop:
            self._loop.create_task(self._worker.shutdown())

    async def _create_temporal_client(self) -> temporalio.client.Client:
        return await temporalio.client.Client.connect(
            namespace=self._temporal_namespace,
            rpc_metadata={"temporal-namespace": self._temporal_namespace},
            target_host=self._temporal_address,
            api_key=self._temporal_api_key,
            tls=self._temporal_api_key is not None,
            data_converter=self._get_data_converter(),
            runtime=temporalio.runtime.Runtime(
                telemetry=temporalio.runtime.TelemetryConfig(
                    logging=temporalio.runtime.LoggingConfig(
                        filter=temporalio.runtime.TelemetryFilter(
                            core_level="INFO", other_level="INFO"
                        ),
                        forwarding=temporalio.runtime.LogForwardingConfig(
                            logger=logging.getLogger("temporalio"),
                        ),
                    )
                )
            ),
        )

    def _get_activities(self) -> List[Callable]:  # type: ignore[type-arg]
        sqc_activities = sqc.SQC(token=self._sqc_token)
        session_activities = SessionActivities(token=self._sqc_token)
        backend_activities = BackendActivities(token=self._sqc_token)
        execute_activities = ExecuteActivities(token=self._sqc_token)
        job_activities = JobActivities(token=self._sqc_token)
        return [
            sqc_activities.send_circuit,
            sqc_activities.get_properties,
            sqc_activities.get_configuration,
            session_activities.start_session,
            session_activities.close_batch,
            backend_activities.get_backend,
            execute_activities.ibm_get_results,
            execute_activities.ibm_send_circuits,
            execute_activities.ibm_wait_for_non_initial_state,
            job_activities.ibm_cancel_jobs,
        ]

    def _get_data_converter(self) -> temporalio.converter.DataConverter:
        data_conv = temporalio.converter.default()
        payload_codec: temporalio.converter.PayloadCodec = (
            qedma_riken.compression_codec.CompressionCodec()
        )
        return dataclasses.replace(data_conv, payload_codec=payload_codec)
